


$(document).on('ready', function () {    
    $('#activity-datatable').DataTable();
});
