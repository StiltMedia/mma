Package.describe({
    summary: "Quick and easy way to build your product tours with Bootstrap Popovers."
});
