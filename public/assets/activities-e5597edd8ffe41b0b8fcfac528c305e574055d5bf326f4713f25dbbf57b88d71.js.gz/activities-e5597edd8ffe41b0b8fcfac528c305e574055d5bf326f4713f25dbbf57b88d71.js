


$(document).on('ready page:load', function () {    
    $('#activity-datatable').DataTable();
});
